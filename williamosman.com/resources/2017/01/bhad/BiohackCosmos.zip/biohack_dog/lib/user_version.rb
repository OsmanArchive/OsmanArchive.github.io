# encoding: ascii-8bit

USER_VERSION = "Unofficial"
